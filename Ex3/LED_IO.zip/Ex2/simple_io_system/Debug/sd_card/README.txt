-= SD card boot image =-

Platform: simple_io_wrapper
Application: simple_io_wrapper

1. Copy the contents of this directory to an SD card
2. Set boot mode to SD
3. Insert SD card and turn board on
